// Service worker — "feels like a real app" caching strategy.
//
// Three-tier strategy:
//   1. Per-wallpaper image bytes (/api/wallpapers/<id>) → cache-first. These
//      are content-addressable and never change once written, so caching
//      forever is safe and makes invite / event pages paint instantly.
//   2. Translation batches → cache responses keyed by request body hash so
//      a returning user sees previously-translated phrases instantly even
//      when the network is slow.
//   3. Everything else under /api/ (gallery list, by-month lookup, events,
//      RSVPs, plan info, etc.) → network-first with a cache fallback for
//      offline grace. Network-first means a fresh upload / upscale /
//      delete / assignment surfaces in the UI on the very next React Query
//      refetch — no manual reload required.
//
// Bump SW_VERSION to invalidate the runtime caches on rollout.

const SW_VERSION = "v28-2026-04-29-day-of-sticky-deeplink";
const WALLPAPER_CACHE = `bigday-wallpapers-${SW_VERSION}`;
const TRANSLATE_CACHE = `bigday-translate-${SW_VERSION}`;
const STATIC_CACHE = `bigday-static-${SW_VERSION}`;

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    // Drop any caches from older SW versions; keep current ones.
    const keep = new Set([WALLPAPER_CACHE, TRANSLATE_CACHE, STATIC_CACHE]);
    const names = await caches.keys();
    await Promise.all(names.filter((n) => !keep.has(n)).map((n) => caches.delete(n)));
    await self.clients.claim();
    // Force every open tab/PWA window to re-navigate so the fresh
    // index.html (which references the new content-hashed JS bundle)
    // is loaded immediately on the next deploy — instead of users
    // seeing a stale shell until they manually close and reopen the
    // app. Without this, a user with the PWA already open keeps
    // running the bundle that was current when their tab loaded.
    try {
      const winClients = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
      for (const client of winClients) {
        try { client.navigate(client.url); } catch {}
      }
    } catch {}
  })());
});

// Only the per-id image endpoint is content-addressable and safe to
// cache aggressively. Lists, lookups and assignments must always be
// network-first so a fresh upload / upscale / delete shows up the moment
// React Query refetches — no manual screen refresh required.
function isImmutableWallpaperImage(url) {
  return /\/api\/wallpapers\/\d+(?:\/invitation)?$/.test(url.pathname);
}

function isTranslateBatch(url) {
  return url.pathname.endsWith("/api/translate-batch");
}

// Cache-first with background refresh ("stale-while-revalidate").
async function staleWhileRevalidate(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  const network = fetch(request)
    .then((res) => {
      if (res && res.ok) cache.put(request, res.clone()).catch(() => {});
      return res;
    })
    .catch(() => null);
  return cached || (await network) || new Response("", { status: 504, statusText: "offline" });
}

// Translate-batch is a POST, so we can't key on URL alone — we hash the
// body and look up the response in our own cache.
async function handleTranslateBatch(request) {
  try {
    const cloned = request.clone();
    const bodyText = await cloned.text();
    const cacheKey = new Request(`${request.url}#${await sha1(bodyText)}`, { method: "GET" });
    const cache = await caches.open(TRANSLATE_CACHE);
    const cached = await cache.match(cacheKey);
    if (cached) {
      // Refresh in background so the cache stays fresh, but return cached now.
      fetch(request).then(async (res) => {
        if (res && res.ok) {
          const copy = res.clone();
          cache.put(cacheKey, new Response(await copy.text(), {
            status: 200,
            headers: { "Content-Type": "application/json" },
          })).catch(() => {});
        }
      }).catch(() => {});
      return cached;
    }
    const fresh = await fetch(request);
    if (fresh && fresh.ok) {
      const copy = fresh.clone();
      const body = await copy.text();
      cache.put(cacheKey, new Response(body, {
        status: 200,
        headers: { "Content-Type": "application/json" },
      })).catch(() => {});
    }
    return fresh;
  } catch {
    return fetch(request);
  }
}

async function sha1(text) {
  const buf = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest("SHA-1", buf);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Translate-batch (POST) → custom hash-keyed cache for instant repeats.
  if (req.method === "POST" && isTranslateBatch(url)) {
    event.respondWith(handleTranslateBatch(req));
    return;
  }

  if (req.method !== "GET") return;

  // Per-id wallpaper image bytes → cache-first. Bytes never change, so
  // returning users see invites / events paint instantly. Lists, by-month
  // lookups and assignments deliberately fall through to the network-first
  // branch below so freshly-uploaded / upscaled / deleted wallpapers
  // appear in the gallery the moment React Query refetches.
  if (isImmutableWallpaperImage(url)) {
    event.respondWith(staleWhileRevalidate(req, WALLPAPER_CACHE));
    return;
  }

  // Other API calls → fresh, with offline fallback.
  if (url.pathname.includes("/api/")) {
    event.respondWith(
      fetch(req, { cache: "no-store" }).catch(
        () => caches.match(req).then((c) => c || new Response("", { status: 504, statusText: "offline" }))
      )
    );
    return;
  }

  // HTML / navigation requests → ALWAYS network-first with cache as
  // offline fallback. The index.html is the entry point that points
  // at the content-hashed JS bundle, so if we serve a stale index.html
  // the user keeps running yesterday's app forever (they'd see no new
  // features and no bug fixes). Network-first guarantees that the
  // moment a new deploy is live, the very next page load picks it up.
  const isNavigation = req.mode === "navigate" ||
    (req.destination === "document") ||
    (req.headers.get("accept") || "").includes("text/html");
  if (isNavigation) {
    event.respondWith(
      (async () => {
        try {
          const fresh = await fetch(req, { cache: "no-store" });
          if (fresh && fresh.ok) {
            const cache = await caches.open(STATIC_CACHE);
            cache.put(req, fresh.clone()).catch(() => {});
          }
          return fresh;
        } catch {
          const cache = await caches.open(STATIC_CACHE);
          const cached = await cache.match(req);
          return cached || new Response("", { status: 504, statusText: "offline" });
        }
      })()
    );
    return;
  }

  // App shell / static assets (hashed JS, CSS, images) → cache-first.
  // These are content-addressable thanks to vite's hashed filenames,
  // so caching them indefinitely is safe.
  event.respondWith(
    (async () => {
      const cache = await caches.open(STATIC_CACHE);
      const cached = await cache.match(req);
      const network = fetch(req)
        .then((res) => {
          if (res && res.ok && (res.type === "basic" || res.type === "default")) {
            cache.put(req, res.clone()).catch(() => {});
          }
          return res;
        })
        .catch(() => null);
      return cached || (await network) || new Response("", { status: 504, statusText: "offline" });
    })()
  );
});

self.addEventListener("push", function (event) {
  if (!event.data) return;
  const data = event.data.json();
  // Action buttons (e.g. "View gifts" / "Not now") are passed straight
  // through to showNotification. We stash the per-action target URLs in
  // the notification's data bag so the click handler can route on tap.
  // Browsers only render the first 1-2 actions in practice; the API
  // tolerates any array length we hand it.
  const actions = Array.isArray(data.actions) ? data.actions : [];
  const actionsUrl = (data.actionsUrl && typeof data.actionsUrl === "object") ? data.actionsUrl : {};
  const options = {
    body: data.body || "Your big day is here!",
    icon: data.icon || "/favicon.svg",
    badge: "/favicon.svg",
    tag: data.tag || "event-day",
    renotify: true,
    vibrate: [200, 100, 200],
    actions: actions,
    // Sticky notifications stay on the lock screen / notification shade
    // until the user explicitly taps or dismisses them. Used for event
    // reminders so "your event is today" doesn't auto-disappear before
    // the recipient has acknowledged it.
    requireInteraction: data.requireInteraction === true,
    data: {
      url: data.url || "/",
      actionsUrl: actionsUrl,
    },
  };
  // Optional large hero image — used by Android/Samsung notification
  // shade to render the swatch on the right (and the expanded big-image
  // view). For our daily motivation push this is a yellow "FEEL
  // INSPIRED" tile so the notification reads on-brand instead of the
  // OS-default red placeholder.
  if (data.image) {
    options.image = data.image;
  }
  event.waitUntil(
    self.registration.showNotification(data.title || "Tomorrow's a BIG DAY®", options)
  );
});

self.addEventListener("notificationclick", function (event) {
  event.notification.close();
  // Routing rules:
  //   - Reserved action id "not-now" → just dismiss, no navigation.
  //   - Any other action id → open data.actionsUrl[action] if mapped,
  //     falling back to the default url so misconfigured pushes still
  //     land somewhere sensible.
  //   - Tap on the body (no action) → open data.url.
  if (event.action === "not-now") return;
  const data = event.notification.data || {};
  const actionUrl = (event.action && data.actionsUrl) ? data.actionsUrl[event.action] : null;
  const url = actionUrl || data.url || "/";
  event.waitUntil((async () => {
    const winClients = await clients.matchAll({ type: "window", includeUncontrolled: true });
    // Prefer reusing an existing PWA window so we don't spawn a second
    // tab. If the open window is already on the target URL we just
    // focus it; otherwise we navigate it to the deep link so a tap on
    // an event-day push always lands on /invite/<id> — not whatever
    // page the calendar happened to be sitting on.
    for (const client of winClients) {
      try {
        const clientPath = new URL(client.url).pathname;
        const targetPath = url.startsWith("http") ? new URL(url).pathname : url.split("?")[0];
        if (clientPath === targetPath) {
          if ("focus" in client) await client.focus();
          return;
        }
      } catch (_) { /* fall through to navigate */ }
    }
    for (const client of winClients) {
      try {
        if ("navigate" in client) {
          const navigated = await client.navigate(url);
          if (navigated && "focus" in navigated) await navigated.focus();
          else if ("focus" in client) await client.focus();
          return;
        }
      } catch (_) { /* navigate may reject cross-origin or detached clients */ }
    }
    if (clients.openWindow) await clients.openWindow(url);
  })());
});

console.log("[sw] version", SW_VERSION);
